/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanbanpoe;

import javax.swing.JOptionPane;


/**
 *
 * @author Phelisa
 */
public class MenuPromptClass {
    public static int menuPrompt (){
       String [] OPTIONS = {"Login", "Register","Exit"};
        
       int selectedOption = JOptionPane.showOptionDialog (
                    null,
                    "Please select an option",
                    "Login/Register",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    OPTIONS,
                    OPTIONS[0]);
               
                   return selectedOption;
    }
                            
    public static void main (String [] args){
        int option = menuPrompt();
        System.out.println("Selected option: " + option);
    }
}


