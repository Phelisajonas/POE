/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanbanpoe;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Phelisa
 */
public class UserAccountClass {
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    
    public UserAccountClass (String firstName, String lastName, String userName, String password){
     this.firstName= firstName;
     this.lastName= lastName;
     this.userName= userName;
     this.password= password;
    }

    @Override 
     public String toString () {
        return "[" + getFirstName() + "," + getLastName() + "," + getUserName() +"," + getPassword() + " ]";
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    public String getLastName () {
        return lastName;
    }
    
    public void setLastName(String lastName){
    this.lastName = lastName;
    }
    
    public String getUserName () {
        return userName;
    }
    
    public void setUserName(String userName){
        this.userName = userName;
    }
    
    public String getPassword () {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
   }
     
    public static UserAccountClass createUserAccount (){
       String firstName = JOptionPane.showInputDialog("Please enter your first name:") ;
       String lastName = JOptionPane.showInputDialog("Please enter your last name:");
       String userName = JOptionPane.showInputDialog("Please enter a username:");
       String password = JOptionPane.showInputDialog("Please enter a password:");
    
      return new UserAccountClass(firstName, lastName, userName, password);
          
    }
     public static UserAccountClass createUserAccount (Scanner input) {
        System.out.println("Enter a first name");
        String fn = input.nextLine();
        System.out.println("Enter a last name");
        String ln = input.nextLine();
        System.out.println("Enter a username");
        String un = input.nextLine();
        System.out.println("Enter a password");
        String pd = input.nextLine();
    
        UserAccountClass aUser = new UserAccountClass(fn, ln, un, pd);
    
        return aUser;
    }
   public static void display(UserAccountClass u) {
        System.out.println(u.toString());
    }
       
}