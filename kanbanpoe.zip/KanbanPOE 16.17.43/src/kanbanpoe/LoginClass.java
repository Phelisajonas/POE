/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanbanpoe;

import java.util.ArrayList;
import kanbanpoe.UserAccountClass;

/**
 *
 * @author Phelisa
 */
public class LoginClass {
             
   private ArrayList < UserAccountClass > registeredUserAccounts = new ArrayList <> ();
      private UserAccountClass currUserAccount = null;
    
        
      public boolean checkUserName(UserAccountClass u) {
            for (UserAccountClass registeredUserAccount : registeredUserAccounts){
                if (registeredUserAccount.getUserName().equals(u.getUserName())){
                    return true;
                }
            }
            return false;
       }
       
       public boolean checkPasswordComplexity(UserAccountClass u) {
        String password = u.getPassword();
        if (password.length() < 8){
            return false;
        }
           return true;

       }
       
       public String registerUser (UserAccountClass u) {
        if (checkUserName (u)) {
            return "This username is already taken, please choose another username.";
        }
        if (!checkPasswordComplexity (u)) {
            return "Password complexity does not meet requirements.";
        }

        registeredUserAccounts.add(u);
        return "user registration is complete";
        
       }
       
      public boolean loginUser(String userName, String password) {
       for (UserAccountClass registeredUserAccount : registeredUserAccounts){
            if (registeredUserAccount.getUserName().equals(userName) && registeredUserAccount.getPassword().equals(password)){
                currUserAccount = registeredUserAccount;
                return true;
            }
        }
           return false;
       }
       
       public String returnLoginStatus() {
        if (currUserAccount != null){
            return "User" + currUserAccount.getUserName() + "logged in.";
        } else {
            return "No user logged in.";
        }

       }
}

   
