package kanbanpoe;

import java.util.Scanner;
import kanbanpoe.MethodsClass;
import kanbanpoe.UserAccountClass;
import kanbanpoe.LoginClass;



// main class for application 
public class POEClass {
    
public static void main(String[] args) {
    dispatchLoop();
 }



    private static void dispatchLoop() {
       Scanner input = new Scanner(System.in);
       UserAccountClass user = null;
       LoginClass controller = new LoginClass ();
       MethodsClass methods = new MethodsClass ();
       
       
       while (true) { 
           methods.menu();
           String choice = methods.getAChoice (input);
           
                   switch (choice) {
               case "1":
                  user = methods.createUserAccount (input);
                         break;
               
               case "2":
                   if (user == null){
                       System.out.println("please create your account first.");
                   } else {
                       controller.loginUserAccount(user);
                   }
                        break;
                        
               case "3":
                   if (user == null){
                       System.out.println("please create your account first.");
                   } else {
                    methods.display(user);
                   }
                        break;
                        
               case "4":
                   System.exit(0);
                        break;
               default:
                   System.out.println("Choice invalid, please try again.");
                       break;
           }
       }
    }
}

        

    
   