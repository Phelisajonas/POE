/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanbanpoe;


/**
 *
 * @author Phelisa
 */
public class TaskAppClass {

    public TaskAppClass(String create_login, int par) {
    }
      private static String [] developers;
      private static String [] taskNames;
      private static String [] taskIDs;
      private static int [] taskDurations;
      private static String [] taskStatuses;
    
      public static void main(String [] args){
          populateArrays();
          displayTaskWithStatus("done");
          displayDeveloperWithLongestDuration();
          searchTaskByName ("create login");
          searchTaskByDeveloper("Mike Smith");
          deleteTaskByName("create reports");
          displayTaskReport();
       
          
          TaskAppClass[] tasks = createTaskObjects();
          int totalHours = returnTotalHours(tasks);
          System.out.println("Total Hours: " + totalHours);
         
      }

       public static TaskAppClass[] createTaskObjects(){
          TaskAppClass[] tasks = new TaskAppClass[4];
         tasks [0] = new TaskAppClass("create login", 5);
         tasks [1]= new TaskAppClass ("create add features", 8);
         tasks [2] = new TaskAppClass("create reports", 2);
         tasks [3] = new TaskAppClass ("create arrays", 11);
         
       return tasks;
       }
      
       public static int returnTotalHours (TaskAppClass[] tasks){
           int totalHours = 0;
           for (TaskAppClass task : tasks){
               int [] taskDurations = task.getTaskDurations ();
               for (int duration : taskDurations){
                   totalHours += duration;
               }
       }
           return totalHours;
       }
      
      
  public static void populateArrays(){
      developers = new String [] { "Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
      taskNames = new String [] {"create login", "create add features", "create reports", "create arrays"};
      taskIDs = new String [] { "01", "02", "03", "04"};
      taskDurations = new int [] { 5, 8, 2, 11};
      taskStatuses = new String [] { "to do", "doing", "done", "to do"};
  }
    
  
      public static void displayTaskWithStatus (String status){
          System.out.println("task with status '" + status + "' :");
          for (int i = 0; i< taskStatuses.length; i++){
              if (taskStatuses[i].equalsIgnoreCase(status)){
                  System.out.println("task ID: " + taskIDs[i]);
                  System.out.println("task name: " + taskNames[i]);
                  System.out.println("task duration: " + taskDurations[i]);
                  System.out.println("task status: " + taskStatuses[i]);
                  System.out.println("--------------");
              }
          }
      }
      

  
      public static void displayDeveloperWithLongestDuration(){
         int longestDuration = 0;
         String developer = "";
         
          for (int i = 0; i < taskDurations.length; i++){
              if (taskDurations[i] > longestDuration ){
                  longestDuration = taskDurations[i];
                  developer = developers [i];
              }
          }
          System.out.println("developer with the longest duration: " + developer + ", Duration: " + longestDuration + "\n");
      }
          
         public static void searchTaskByName (String developer) {
             System.out.println("Searching for the task with name ' " + taskNames + "' :");
          for (int i =0; i < taskNames.length; i++){
              if (taskNames[i].equalsIgnoreCase(developer)){
                  System.out.println("Task Name: " + taskNames[i] + ", Developer: " + developers[i] + ", Task Status: " + taskStatuses[i]);
              }
          }
          System.out.println();
         }
         
         
         public static void searchTaskByDeveloper(String developer){
         System.out.println("searching for tasks assigned to the developer ' " + developer + "':");
         for (int i=0; i < developers.length; i++){
             if (developers[i].equalsIgnoreCase(developer)){
                 System.out.println("Task name: " + taskNames[i] + ", task status: " + taskStatuses[i]);
             }
         }
         System.out.println();
         }
         

         public static void deleteTaskByName(String taskName){
        System.out.println("deleting task with name '" + taskName + "' : " );
         for (int i=0; i < taskNames.length; i++){
             if (taskNames[i].equalsIgnoreCase(taskName)){
                 // deletes task by shifting the elements 
                for (int j = i; j < taskNames.length - 1; j++){
                    developers [j] = developers [j];
                }
             }
         }
         
   
    public static void displayTaskReport(){
            System.out.println("task report:");
            for (int i=0; i < taskNames.length; i++){
                     System.out.println("task ID: " + taskIDs[i]);
                     System.out.println("task name: " + taskNames[i]);
                     System.out.println("task duration: " + taskDurations[i]);
                     System.out.println("task status: " + taskStatuses[i]);
                     System.out.println("--------------");
                     
            }
         }
        
         
         }
         
         

         
         
         
         
    
    
            
    






    


    



    
    


    


    

                                                                    



