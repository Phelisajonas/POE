/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanbanpoe;

import java.util.Scanner;
/**
 *
 * @author Phelisa
 */
public class MethodsClass {
        public static void menu() {
        System.out.println("1. Create a User Account");
        System.out.println("2. Login User");
        System.out.println("3. Display User Details");
        System.out.println("4. Quit");
     }
   
   public static String getAChoice (Scanner input) {
        return input.nextLine();
     }
   
   public static UserAccountClass createUserAccount (Scanner input) {
        System.out.println("Enter a first name");
        String fn = input.nextLine();
        System.out.println("Enter a last name");
        String ln = input.nextLine();
        System.out.println("Enter a username");
        String un = input.nextLine();
        System.out.println("Enter a password");
        String pd = input.nextLine();
    
        UserAccountClass aUser = new UserAccountClass (fn, ln, un, pd);
    
        return aUser;
    }
   public static void display(UserAccountClass u) {
        System.out.println(u.toString());
    }
}
   
    
      

