/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanbanpoe;

import java.util.Scanner;


/**
 *
 * @author Phelisa
 */
public class KanbanClass {
    public static void main (String[] args){
   
        // welcoming message 
    System.out.println("Welcome to EasyKanban");
    
    Scanner scanner = new Scanner (System.in);
    
   System.out.print("Username:");
   String userName = scanner.nextLine();
  
   System.out.print("Password:");
   String password = scanner.nextLine();

    
    // user account details 
   String correctUserName = "Phelisa Jonas";
   String correctPassword = "Password";
    
    boolean isLoggedIn = userName.equals(correctUserName) && password.equals(correctPassword);
    
    if (isLoggedIn){
        System.out.println("Successfully logged in. Your tasks can now be added");
       
    } else {
        System.out.println("Login failed. Exiting Application.");
    }
}  
}