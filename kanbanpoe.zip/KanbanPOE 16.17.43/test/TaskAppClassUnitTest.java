/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Phelisa
 */
public class TaskAppClassUnitTest {
    

    

 @Test
     
  public void testPopulateArrays() {
      TaskApp.populateArrays();
      
      String[] expectedDevelopers = { "Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
      String[] expectedTaskNames = {  "create login", "create add features", "create reports", "create arrays"};
      String[] expectedTaskIDs = { "01","02","03","04"};
      int[] expectedTaskDurations = {5,8,2,11};
      String[] expectedTaskStatuses = {"to do", "doing", "done", "to do"};
      
      Assertions.assertArrayEquals(expectedDevelopers, TaskApp.getDevelopers());
      Assertions.assertArrayEquals(expectedTaskNames, TaskApp.getTaskNames());
      Assertions.assertArrayEquals(expectedTaskIDs, TaskApp.getTaskIDs());
      Assertions.assertArrayEquals(expectedTaskDurations, TaskApp.getTaskDurations());
      Assertions.assertArrayEquals(expectedTaskStatuses, TaskApp.getTaskStatuses());
  }
  
    
    @Test
    public void testDisplayTasksWithStatus() {
        TaskApp.populateArrays();
        
        String expectedOutput = "Tasks with status 'done':\n" +
                                 "Developer: [Developer Name], Task Name: [Task Name], Task Duration: [Task Duration]\n";
        
        ByteArrayOutputStream outputStrream = new ByteArrayOutputStream();
        PrintStream originalPrintStream = System.out;
        System.setOut(new PrintStream(outputStream));
        
        TaskApp.displayTasksWithStatus("done");
        
        
        String actualOutput = outputStream.toString();
        
        Assertions.assertEquals(expectedOutput, actualOutput);
        
        
        // restores original PrintStream
        System.setOut(originalPrintStream);
        
    }
    
    @Test
    public void testDisplayDeveloperWithLongestDuration() {
    }
    
    @Test
    public void testSearchTaskByName() {
    }
    
    @Test
    public void testSearchTasksByDeveloper() {
    }

    @Test
    public void testDeleteTaskByName(){
        
    }
    
    @Test
    public void testDisplayTaskReport(){
        
    }
    
  }

